package com.rahmananda.aplikasifirebase;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BiodataAdapter extends RecyclerView.Adapter<BiodataAdapter.ViewHolder> {

    List<BiodataModel> biodataModels;
    Context context;

    public BiodataAdapter(List<BiodataModel>biodataModels, Context context){
        this.biodataModels = biodataModels;
        this.context = context;
    }

    @NonNull
    @Override
    public BiodataAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_biodata,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BiodataAdapter.ViewHolder holder, int position) {
        holder.tvNama.setText(biodataModels.get(position).getNama());
        holder.tvAlamat.setText(biodataModels.get(position).getAlamat());
        holder.tvGender.setText(biodataModels.get(position).getGender());
        holder.tvPendidikan.setText(biodataModels.get(position).getPendidikan());
    }

    @Override
    public int getItemCount() {
        return biodataModels.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvNama, tvAlamat, tvGender, tvPendidikan;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvNama = itemView.findViewById(R.id.tv_nama);
            tvAlamat = itemView.findViewById(R.id.tv_alamat);
            tvGender = itemView.findViewById(R.id.tv_gender);
            tvPendidikan = itemView.findViewById(R.id.tv_pendidikan);

        }
    }
}
