package com.rahmananda.aplikasifirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class RealTimeDatabaseActivity extends AppCompatActivity {

    private EditText edtNama, edtAlamat;
    private RadioButton rbLakiLaki, rbPerempuan;
    private Spinner spinPendidikan;
    private Button btnSimpan;
    private RecyclerView rvBiodata;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("Biodata");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_real_time_database);

        edtNama = findViewById(R.id.edt_nama);
        edtAlamat = findViewById(R.id.edt_alamat);
        rbLakiLaki = findViewById(R.id.rb_laki_laki);
        rbPerempuan = findViewById(R.id.rb_perempuan);
        spinPendidikan = findViewById(R.id.spin_pendidikan);
        btnSimpan = findViewById(R.id.btn_simpan);
        rvBiodata = findViewById(R.id.rv_biodata);

        rvBiodata.setLayoutManager(new LinearLayoutManager(this));
        rvBiodata.setHasFixedSize(true);

        reloadData();

        String[] pendidikan = {"pilih pendidikan","SD","SMP","SMA","Perguruan Tinggi"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, pendidikan);
        spinPendidikan.setAdapter(adapter);

        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama = edtNama.getText().toString();
                String alamat = edtAlamat.getText().toString();
                String gender = null;
                String pendidikan = spinPendidikan.getSelectedItem().toString();

                if (TextUtils.isEmpty(nama)){
                    edtNama.setError("Nama Tidak Boleh Kosong");
                }else if (TextUtils.isEmpty(alamat)){
                    edtAlamat.setError("Alamat Tidak Boleh Kosong");
                }else if (! rbPerempuan.isChecked() && !rbLakiLaki.isChecked()){
                    Toast.makeText(RealTimeDatabaseActivity.this, "Pilih Jenis Kelamin", Toast.LENGTH_SHORT).show();
                }else if (spinPendidikan.equals("Pilih Pendidikan")){
                    Toast.makeText(RealTimeDatabaseActivity.this, "Pilih Pendidikan", Toast.LENGTH_SHORT).show();
                }else {
                    if (rbLakiLaki.isChecked()){
                        gender = rbLakiLaki.getText().toString();
                    }else if (rbPerempuan.isChecked()){
                        gender = rbPerempuan.getText().toString();
                    }


                }BiodataModel biodataModel = new BiodataModel();
                biodataModel.setNama(nama);
                biodataModel.setAlamat(alamat);
                biodataModel.setGender(gender);
                biodataModel.setPendidikan(pendidikan);

                String chillID = myRef.push().getKey();
                myRef.child(chillID).setValue(biodataModel).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(RealTimeDatabaseActivity.this, "Data Berhasil Di Simpan", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(RealTimeDatabaseActivity.this, "Data Gagal Di Simpan", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });
    }
    public void reloadData(){
        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
//                String value = dataSnapshot.getValue(String.class);
//                Log.d(TAG, "Value is: " + value);
                ArrayList<BiodataModel> biodataModelsArrayList = new ArrayList<>();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    BiodataModel biodataModel = snapshot.getValue(BiodataModel.class);
                    biodataModel.setId(snapshot.getKey());
                    biodataModelsArrayList.add(biodataModel);
                }
                BiodataAdapter biodataAdapter = new BiodataAdapter(biodataModelsArrayList, RealTimeDatabaseActivity.this);
                biodataAdapter.notifyDataSetChanged();
                rvBiodata.setAdapter(biodataAdapter);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
//                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }
}
